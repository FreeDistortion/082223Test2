package api.util;
//ArrayListExam03 -> BoardExam처럼 변환
//Student class 만들어서 작업
public class ArrayListExam04_StudentDTO {
	public static void main(String[] args) {
		
	}
}
