public class Prob10 {
	public static void main(String[] args) {
		int month = Integer.parseInt(args[0]);
		printSeason(month);
		printSeason(month);
	}

	private static void printSeason(int month) {
		// �����Ͻÿ�.
	}
}
