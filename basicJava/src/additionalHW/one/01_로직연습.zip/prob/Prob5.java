
public class Prob5 {
	public static void main(String args[]) {
		Prob5 p5=new Prob5();
		System.out.println(p5.gcd(2,5));
		System.out.println(p5.gcd(5,15));
		System.out.println(p5.gcd(250,30));
	}
	public int gcd(int num1,int num2) {

	}


}