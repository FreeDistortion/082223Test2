public class BookMgr {
	
	public BookMgr(Book[] booklist) {
	}
	
	public void printBooklist(){

	}
	
	public void printTotalPrice(){

	}
}
