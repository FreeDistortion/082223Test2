public class Hex2Decimal {
	
	/*  이곳에 프로그램을 작성하십시오. */
	
}
