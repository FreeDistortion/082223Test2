public class Student {

	private String name;	//�л��̸�
	private int midScore;	//�߰�����
	private int endScore;	//�߰�����
	private int taskScore;	//�߰�����	
	private String grade;	//���
	
	public Student(String name) { 
		this.name = name;
	}
	
	public Student(String name, int midScore, int endScore, int taskScore) { 
		this.name = name;
		this.midScore = midScore;
		this.endScore = endScore;
		this.taskScore = taskScore;
	}
	
	public void calcGrade() {
		int avgScore = 0;
		
		avgScore = (int)(midScore*0.4 + endScore*0.4 + taskScore*0.2);
		
		if(avgScore >= 90) {
			grade = "A";
		} else if(avgScore >= 80) {
			grade = "B";
		} else if(avgScore >= 70) {
			grade = "C";
		} else if(avgScore >= 60) {
			grade = "D";
		} else {
			grade = "F";
		} 
	} 

	public int getEndScore() {
		return endScore;
	}

	public void setEndScore(int endScore) {
		this.endScore = endScore;
	}

	public int getMidScore() {
		return midScore;
	}

	public void setMidScore(int midScore) {
		this.midScore = midScore;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTaskScore() {
		return taskScore;
	}

	public void setTaskScore(int taskScore) {
		this.taskScore = taskScore;
	}
	
	
	public String getGrade() {
		return grade;
	}
	
	public String toString() {
		return name +":"+grade;
	}
	

}
