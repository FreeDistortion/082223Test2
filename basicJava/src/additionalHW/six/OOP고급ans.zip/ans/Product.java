
public class Product { 
	private int productCode;
	private double productCost;
	private int numOfProduct;
	private int numOfPack;

	public int getProductCode() {
		return productCode;
	}

	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}

	public double getProductCost() {
		return productCost;
	}

	public void setProductCost(double productCost) {
		this.productCost = productCost;
	}

	public int getNumOfProduct() {
		return numOfProduct;
	}

	public void setNumOfProduct(int numOfProduct) {
		this.numOfProduct = numOfProduct;
	}

	public int getNumOfPack() {
		return numOfPack;
	}

	public void setNumOfPack(int numOfPack) {
		this.numOfPack = numOfPack;
	}

}
