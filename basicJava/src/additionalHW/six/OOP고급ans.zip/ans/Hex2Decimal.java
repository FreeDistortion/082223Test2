import java.util.Scanner;

public class Hex2Decimal {
	
	public static void main(String[] args) {
		String value = "";
		Scanner keyboard = new Scanner(System.in);
		System.out.print("Enter the hex value ('quit' for exit) : ");
		while (!(value = keyboard.next()).equalsIgnoreCase("quit")) {
			try {
				value = value.toUpperCase();
				System.out.println("hex input : "+value);
				int dec = new Hex2Decimal().convert(value);
				System.out.println("decimal output : "+dec);
				System.out.println("===========================================");
				System.out.print("Enter the hex value ('quit' for exit) : ");
			} catch (IllegalArgumentException e) {
				System.out.println("Invalid hex !!!");
				System.out.println("===========================================");
				System.out.print("Enter the hex value ('quit' for exit) : ");
			}
		}
		System.out.println("Bye !!!");
	}
	
	public int hex2dec(char ch) throws IllegalArgumentException {
		
		int ret = 0;
		if (ch >= 'A' && ch <= 'F')	ret = ch-'A'+10;
		else if (ch >= '0' && ch <= '9') ret = ch-'0';
		else throw new IllegalArgumentException();
		
		return ret;
	}
	
	public int convert(String hex) throws IllegalArgumentException {
		int dec = 0;
		for (int i=hex.length()-1;i>=0;i--) {
			char ch = hex.charAt(hex.length()-i-1);
			if ((ch < 'A' || ch > 'F') && (ch < '0' || ch > '9'))
				throw new IllegalArgumentException();
			
			dec += Math.pow(16, i) * hex2dec(ch); 
		}
		
		return dec;
	}
}
