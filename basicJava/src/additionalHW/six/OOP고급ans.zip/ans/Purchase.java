﻿import java.io.BufferedReader;
import java.io.InputStreamReader; 

public class Purchase {
	private static String nameOfProduct[] = { "사과", "오렌지", "포도", "딸기" };
	private static int totalStockOfPack[] = { 3, 5, 20, 1 };

	public static void main(String[] args) throws Exception {
		Purchase purchase = new Purchase();

		Product product = purchase.getProduct();
		double totalPrice = purchase.calcTotalPrice(product);

		StringBuffer sb = new StringBuffer();
		if (totalPrice == -1)
			sb.append("재고가 없어 " + product.getNumOfPack() + "개의 "
					+ nameOfProduct[product.getProductCode() - 1]
					+ " 상품팩에 대한 구매가 불가합니다. 죄송합니다.");
		else {
			sb.append(product.getNumOfPack() + "개의 "
					+ nameOfProduct[product.getProductCode() - 1]
					+ " 상품팩을 구매하셨습니다.");
			sb.append(nameOfProduct[product.getProductCode() - 1]
					+ " 한 개의 가격은 "
					+ Math.round(product.getProductCost()
							/ product.getNumOfProduct()) + "원이며, 지불해야 할 총 금액은 "
					+ totalPrice + "원입니다.");
		}

		System.out.println(sb.toString());
	}

	public Product getProduct() throws Exception {
		Product product = new Product();
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("구매하려는 상품 코드를 선택하세요. [1:사과,2:오렌지,3:포도,4:딸기] ? ");
		product.setProductCode(new Integer(in.readLine()).intValue());

		System.out.print("상품팩에 포함된 상품의 개수, 상품팩의 가격을 순서대로 입력하세요 (구분자:,) ? ");
		String line = in.readLine();
		String[] packDetail = line.split(",");
		product.setNumOfProduct(Integer.valueOf(packDetail[0]));
		product.setProductCost(Double.valueOf(packDetail[1]));

		System.out.print("구매하려는 상품팩의 개수를 입력하세요 ? ");
		product.setNumOfPack(new Integer(in.readLine()).intValue());
		return product;
	}

	public double calcTotalPrice(Product product) throws Exception {
		int productCode = product.getProductCode();
		if (totalStockOfPack[productCode - 1] < product.getNumOfPack())
			return -1;
		else
			return product.getNumOfPack() * product.getProductCost();
	}
}

