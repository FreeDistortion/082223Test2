package additionalHW.six.one;



// 수정하지 말고 그대로 사용하세요.
public interface Payable {
	public void pay() throws PayException ;
}
