public class AnimalTest {
	public static void main(String[] args) {
		Animal dog = new Dog(8);
		Animal chicken = new Chicken(3);
		Chicken cheatableChicken = new Chicken(5);
		if(ceatableChicken instanceof Chicken){
			cheatableChicken.fly();
		}
	}
}












